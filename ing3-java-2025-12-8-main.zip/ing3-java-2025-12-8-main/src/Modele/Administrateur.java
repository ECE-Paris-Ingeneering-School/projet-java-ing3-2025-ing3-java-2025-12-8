package Modele;

public class Administrateur {
}

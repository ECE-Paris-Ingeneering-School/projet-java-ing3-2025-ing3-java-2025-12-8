package Modele;

public class LigneCommande {
}

package Vue;

public class StatistiqueFrame {
}
